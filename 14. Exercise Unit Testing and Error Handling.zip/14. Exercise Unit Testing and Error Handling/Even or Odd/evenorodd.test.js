const {expect} = require('chai');
const {isOddOrEven} = require('./evenorodd');

describe('isOddOrEven', () => {
    it('Should return undefined if input is not a string', () => {
        expect(isOddOrEven(1)).to.be.undefined;
    });
    it('Should return even if input is even', () => {
        expect(isOddOrEven('21')).to.equal('even');
    });
    it('Should return odd if input is odd', () => {
        expect(isOddOrEven('1')).to.equal('odd');
    });
    it('should return even when string is even', ( ) => {
        expect(isOddOrEven('even')).to.equal('even');
    });
    it('should return odd when string is odd', ( ) => {
        expect(isOddOrEven('odd')).to.equal('odd');
    });
});