function notify(message) {
  let notifyBtn = document.getElementById('notification');
  notifyBtn.textContent = message;
  notifyBtn.style.display = 'block';
  notifyBtn.addEventListener('click', () => {
    notifyBtn.style.display = 'none';
  });
}