function validate() {
  let emailInput = document.getElementById("email");

  function isValid(email) {
    if (/^[a-z]+@[a-z]+\.[a-z]+/g.test(email)) {
      return true;
    } else {
      return false;
    }
  }

  function styleChange(email, val) {
    if (isValid(val)) {
      email.className = "";
    } else {
      email.className = "error";
    }
  }

  emailInput.addEventListener("change", (e) =>
    styleChange(e.target, e.target.value)
  );
}
