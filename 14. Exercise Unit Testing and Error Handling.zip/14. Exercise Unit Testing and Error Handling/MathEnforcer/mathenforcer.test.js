const {expect} = require('chai');
const {mathEnforcer} = require('./mathEnforcer');

describe('mathEnforcer', () => {
    describe('addFive', () => {
        it('should return correct result with a non-number parameter', () => {
            expect(mathEnforcer.addFive('string')).to.be.undefined;
        })
        it('should return correct result with a number parameter', () => {
            expect(mathEnforcer.addFive(10)).to.equal(15);
        })
        it('should return correct result with a negative number parameter', () => {
            expect(mathEnforcer.addFive(-10)).to.equal(-5);
        })
        it('should return correct result with a floating point number parameter', () => {
            expect(mathEnforcer.addFive(10.5)).to.equal(15.5);
        })  
        it('should return correct result with a floating point number parameter', () => {
            expect(mathEnforcer.addFive(0.1)).to.be.closeTo(5.1, 0.01);
        })
    })
    describe('subtractTen', () => {
        it('should return correct result with a non-number parameter', () => {
            expect(mathEnforcer.subtractTen('string')).to.be.undefined;
        })
        it('should return correct result with a number parameter', () => {
            expect(mathEnforcer.subtractTen(10)).to.equal(0);
        })
        it('should return correct result with a negative number parameter', () => {
            expect(mathEnforcer.subtractTen(-10)).to.equal(-20);
        })
        it('should return correct result with a floating point number parameter', () => {
            expect(mathEnforcer.subtractTen(10.5)).to.equal(0.5);
        })
        it('should return correct result with a floating point number parameter', () => {
            expect(mathEnforcer.subtractTen(0.1)).to.be.closeTo(-9.9, 0.01);
        })
    })
    describe('sum', () => {
        it('should return correct result with a non-number parameter', () => {
            expect(mathEnforcer.sum('string', 1)).to.be.undefined;
        })
        it('should return correct result with a non-number parameter', () => {
            expect(mathEnforcer.sum(1, 'string')).to.be.undefined;
        })
        it('should return correct result with a number parameter', () => {
            expect(mathEnforcer.sum(1, 1)).to.equal(2);
        })
        it('should return correct result with a negative number parameter', () => {
            expect(mathEnforcer.sum(-1, -1)).to.equal(-2);
        })
        it('should return correct result with a floating point number parameter', () => {
            expect(mathEnforcer.sum(1.5, 1.5)).to.equal(3);
        })
        it('should return correct result with a floating point number parameter', () => {
            expect(mathEnforcer.sum(0.1, 0.1)).to.be.closeTo(0.2, 0.01);
        })
    })
});

