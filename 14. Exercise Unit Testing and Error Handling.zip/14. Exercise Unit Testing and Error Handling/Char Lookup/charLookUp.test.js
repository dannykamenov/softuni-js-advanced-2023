const {expect} = require('chai');
const {lookupChar} = require('./charLookUp');

describe('lookupChar', () => {
    it('should return undefined if first param is not a string', () => {
        expect(lookupChar(5,5)).to.be.undefined;
    })
    it('should return undefined if second param is not a number', () => {
        expect(lookupChar('test','test')).to.be.undefined;
    })
    it('should return undefined if second param is not an integer', () => {
        expect(lookupChar('test',5.5)).to.be.undefined;
    })
    it('should return Incorrect index if index is <0', () => {
        expect(lookupChar('test',-1)).to.equal('Incorrect index');
    })
    it('should return Incorrect index if index is >string.length', () => {
        expect(lookupChar('test',5)).to.equal('Incorrect index');
    })
    it('should return Incorrect index if index is =string.length', () => {
        expect(lookupChar('test',4)).to.equal('Incorrect index');
    })
    it('should return correct char', () => {
        expect(lookupChar('test',0)).to.equal('t');
    })
    it('should return correct char 2', () => {
        expect(lookupChar('test',3)).to.equal('t');
    })
    it('should return correct char 3', () => {
        expect(lookupChar('t',0)).to.equal('t');
    })
});