const { expect } = require('chai');
const summing = require('./SumOfNumbers');

describe('Sum Tester', () => {
    it('summing works', () => {
        expect(summing.sum([1,2])).to.equal(3);
    })
    it('works with strings', () => {
        expect(summing.sum(['1', '2'])).to.equal(3);
    })
})