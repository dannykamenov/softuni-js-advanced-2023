const sum = require('./myModule');

console.log(sum(3,5));

// or can use export as object and then it would be "const sum = require('./myModule').sum" or "const {sum} = require('./myModule')";