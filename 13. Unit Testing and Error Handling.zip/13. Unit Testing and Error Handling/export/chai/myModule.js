const { describe } = require("mocha");

function sum(a,b){
    return a + b;
}

//module.exports = sum;
