const { expect } = require('chai');
const { createCalculator } = require('./AddSubtract');

describe('AddSubtract', () => {
    it('should return an object', () => {
        expect(createCalculator()).to.be.an('object');
    })
    it('should return an object with the correct properties add', () => {
        expect(createCalculator().add()).to.equal('yes');;
    });
    it('should return an object with the correct properties subtract', () => {
        expect(typeof createCalculator().subtract).to.equal('function');
    });
    it('should return an object with the correct properties get', () => {
        expect(typeof createCalculator().get).to.equal('function');
    });
    it('should correctly use add and subtract with a number', () => {
        const calculator = createCalculator();
        calculator.add(2);
        calculator.subtract(1);
        expect(calculator.get()).to.equal(1);
    })
    it('should correctly use add and subtract with a parsed number', () => {
        const calculator = createCalculator();
        calculator.add('2');
        calculator.subtract('1');
        expect(calculator.get()).to.equal(1);
    })
    it('should not let value to be modified', () => {
        expect(createCalculator().value).to.equal(undefined);
    })
})