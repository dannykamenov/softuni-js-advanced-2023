const { expect } = require('chai');
const { rgbToHexColor } = require('./rgbtohex');

describe('rgbToHexColor', () => {
    it('should return undefined if red is <0', () => {
        expect(rgbToHexColor(-1,5,5)).to.be.undefined;
    })
    it('should return undefined if red is >255', () => {
        expect(rgbToHexColor(256,5,5)).to.be.undefined;
    })
    it('should return undefined if red is not a number', () => {
        expect(rgbToHexColor('test',5,5)).to.be.undefined;
    })
    it('should return undefined if blue is <0', () => {
        expect(rgbToHexColor(5,5,-1)).to.be.undefined;
    })
    it('should return undefined if blue is >255', () => {
        expect(rgbToHexColor(5,5,256)).to.be.undefined;
    })
    it('should return undefined if blue is not a number', () => {
        expect(rgbToHexColor(5,5,'test')).to.be.undefined;
    })
    it('should return undefined if green is <0', () => {
        expect(rgbToHexColor(5,-1,6)).to.be.undefined;
    })
    it('should return undefined if green is >255', () => {
        expect(rgbToHexColor(5,256,6)).to.be.undefined;
    })
    it('should return undefined if green is not a number', () => {
        expect(rgbToHexColor(5,'test',7)).to.be.undefined;
    })
    it('all valid should return hex', () => {
        expect(rgbToHexColor(255,255,255)).to.equal('#FFFFFF');
    })
    it('all valid should return hex 2', () => {
        expect(rgbToHexColor(109,136,181)).to.equal('#6D88B5');
    })
    it('all valid should return hex 3', () => {
        expect(rgbToHexColor(0,0,0)).to.equal('#000000');
    })
})