const { expect } = require('chai');
const { isSymmetric } = require('./CheckSymmetry');

describe('Checking Symmetry', () => {
    it('It is not an array', () => {
        expect(isSymmetric(1)).to.be.false;
    });
    it('Letter is not symmetric', () => {
        expect(isSymmetric('a')).to.be.false;
    });
    it('It is symmetric as numbers', () => {
        expect(isSymmetric([1,2,1])).to.be.true;
    })
    it('It is symmetric as string', () => {
        expect(isSymmetric(['1','2','1'])).to.be.true;
    })
    it('It is symmetric as letter string', () => {
        expect(isSymmetric(['a','b','a'])).to.be.true;
    })
    it('It is not symmetric as number', () => {
        expect(isSymmetric([1,2,3])).to.be.false;
    })
    it('It is not symmetric as number string', () => {
        expect(isSymmetric(['1','2','3'])).to.be.false;
    })
    it('It is not symmetric as letter', () => {
        expect(isSymmetric(['a','b','c'])).to.be.false;
    })
    it('It is symmetric with 1 input as arr', () => {
        expect(isSymmetric([1])).to.be.true;
    })
    it('It is symmetric with 1 input as arr 2', () => {
        expect(isSymmetric(['1'])).to.be.true;
    })
    it('It is symmetric with 1 input as arr 3', () => {
        expect(isSymmetric(['a'])).to.be.true;
    })
    it('It is symmetric with 2 input as arr ', () => {
        expect(isSymmetric([1,1])).to.be.true;
    })
    it('It is symmetric with 2 input as arr 2', () => {
        expect(isSymmetric(['1','1'])).to.be.true;
    })
    it('It is symmetric with 2 input as arr 3', () => {
        expect(isSymmetric(['a','a'])).to.be.true;
    })
    it('It is symmetric with 2 input as arr 4', () => {
        expect(isSymmetric([1,'a'])).to.be.false;
    })
    it('It is symmetric with 2 input as arr 5', () => {
        expect(isSymmetric(['1','2','2',1])).to.be.false;
    })
    
});