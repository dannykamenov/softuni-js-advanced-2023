function printDeckOfCards(cards){
    let finalArr = [];


    for(let card of cards){
        const a = card.slice(0, -1);
        const b = card.slice(-1);
        
        try {
            const newCard = createCard(a,b);
            finalArr.push(newCard);
        } catch(err){
            finalArr = ['Invalid card: ' + card];
        }
    }


    console.log(finalArr.join(' '));


    function createCard(a,b){
        let faces = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
        if(faces.indexOf(a) == -1){
            throw new Error(`Invalid face: ${a}`);
        }
        let suits = {
            'S': '\u2660', 
            'H': '\u2665', 
            'D': '\u2666', 
            'C': '\u2663'
        };
        if(suits[b] == undefined){
            throw new Error(`Invalid suit: ${b}`);
        }
        const result = {
            a,
            b: suits[b],
            toString() {
                return this.a + this.b;
            }
        };
    
        return result;
    }
}

printDeckOfCards(['AS', '10D', 'KH', '2C']);
printDeckOfCards(['5S', '3D', 'QD', '1C']);