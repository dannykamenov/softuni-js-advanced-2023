function solve(a,b){
    let faces = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    if(faces.indexOf(a) == -1){
        throw new Error(`Invalid face: ${a}`);
    }
    let suits = {
        'S': '\u2660', 
        'H': '\u2665', 
        'D': '\u2666', 
        'C': '\u2663'
    };
    let result = {
        a,
        b: suits[b],
        toString() {
            return this.a + this.b;
        }
    }

    return result;
}

console.log(solve('11','S').toString());